### Project Info

Hello there,
I hope you are doing well.

This is the *version 1.1* so I will upload another one if my project needs editing. Please ignore my version 1.0 that I sent you a few days ago.

### What's New in this version?
* added a test case
* changed the definition of the function


Thanks in advance

## Navid All Gharaee
### 9722762417
